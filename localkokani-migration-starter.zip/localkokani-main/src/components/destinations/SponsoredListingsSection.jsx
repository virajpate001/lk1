// src/components/destinations/SponsoredListingsSection.jsx
"use client";

import HotelCard from "@/components/hotels/HotelCard";
import RestaurantCard from "@/components/restaurants/RestaurantCard";
import CardCarousel from "@/components/ui/CardCarousel";
import { FiZap } from "react-icons/fi";

function interleave(hotels, restaurants) {
  const result = [];
  const maxLength = Math.max(hotels.length, restaurants.length);

  for (let i = 0; i < maxLength; i++) {
    if (hotels[i]) result.push({ type: "hotel", data: hotels[i] });
    if (restaurants[i]) result.push({ type: "restaurant", data: restaurants[i] });
  }

  return result;
}

export default function SponsoredListingsSection({
  sponsoredHotels = [],
  sponsoredRestaurants = [],
  destinationName,
  title,
  excludeHotelId,
  excludeRestaurantId,
}) {
  const filteredHotels = excludeHotelId
    ? sponsoredHotels.filter((h) => h.id !== excludeHotelId)
    : sponsoredHotels;

  const filteredRestaurants = excludeRestaurantId
    ? sponsoredRestaurants.filter((r) => r.id !== excludeRestaurantId)
    : sponsoredRestaurants;

  const mixedItems = interleave(filteredHotels, filteredRestaurants);

  if (mixedItems.length === 0) return null;

  return (
    <section className="py-12 bg-primary/5 overflow-hidden">
      <div className="container-custom">
        <div className="flex items-center gap-2 mb-2">
          <FiZap className="text-primary" />
           <span className="text-primary dark:text-white font-semibold text-sm uppercase tracking-wider">
            Premium
          </span>
        </div>
        <h2 className="section-title mb-10">
          {title || `Recommended in ${destinationName}`}
        </h2>

        <CardCarousel
          items={mixedItems}
          navPrefix="sponsored"
          renderItem={(item) =>
            item.type === "hotel" ? (
              <HotelCard hotel={item.data} sponsored />
            ) : (
              <RestaurantCard restaurant={item.data} sponsored />
            )
          }
        />
      </div>
    </section>
  );
}